#mete no github

import tkinter as tk

root=tk.Tk()
root.geometry('500x540')

def pretob():
    global preto
    preto=root.configure(background='black')

def azulb():
    global azul
    azul=root.configure(background='blue')

def vermelhob():  
    global vermelho
    vermelho=root.configure(background='red')

def verdeb():
    global verde
    verde=root.configure(background='green')

labe= tk.Label(root,text='Clica num botão para mudar a cor')
labe.pack()

botaoazul=tk.Button(root,text='Azul',height= 10, width=20,command=azulb)
botaoazul.place(x=75,y=50)

botaoverde=tk.Button(root,text='Verde',height= 10, width=20,command=verdeb)
botaoverde.place(x=75,y=300)

botaopreto=tk.Button(root,text='Preto',height= 10, width=20,command=pretob)
botaopreto.place(x=300,y=300)

botaovermelho=tk.Button(root,text='Vermelho',height= 10, width=20,command=vermelhob)
botaovermelho.place(x=300,y=50)

root.mainloop()