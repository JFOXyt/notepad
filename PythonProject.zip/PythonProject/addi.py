lin=0

with open('exemplo.txt','a') as arquivo:
    arquivo.write('\nLinha {}'.format(lin))

lin+=1