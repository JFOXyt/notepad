import tkinter as tk
import pygame

pygame.init()
root=tk.Tk()
root.title('Casino')
root.geometry('500x640')

numer=0
numi=0

def numi():
    global numer
    numer+=1
    num.config(text=numer)

texto=tk.Label(root,text='Pressiona no botao',font=('Arial',20))
texto.pack(pady=100)

num=tk.Label(root,text=numer,font=('Arial',50),pady=-50)
num.pack()

button=tk.Button(root,text='BOTÃO',command=numi,font=('Arial',15),pady=-50)
button.pack(pady=30)

if numer==100 and numi==0:
    print('\033[34mGG 100 clicks')
    conq1=pygame.mixer.music.load('minerare.mp3')
    pygame.mixer.music.play()
    numi=1

if numer==500 and numi==1:
    print('\033[34mGG 500 clicks')
    conq2=pygame.mixer.music.load('minerare.mp3')
    pygame.mixer.music.play()
    numi=2

if numer==1000 and numi==2:
    print('\033[34mGG 1000 clicks')
    conq3=pygame.mixer.music.load('minerare.mp3')
    pygame.mixer.music.play()
    numi=3

root.mainloop()