import tkinter as tk

root=tk.Tk()
root.geometry('500x640')

def media():
    num1=float(input('Num 1:'))
    num2=float(input('Num 2:'))
    med=(num1+num2)/2
    print('Media',med)

text=tk.Label(root,text='Fazer media')
text.pack()

but=tk.Button(root,text='Media',command=media)
but.pack()

root.mainloop()