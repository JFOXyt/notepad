with open('write.txt','w') as file1:
    file1.write('Bom dia')