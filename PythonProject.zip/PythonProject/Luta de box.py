import random,time,sys

def dano():
    dano=random.randint(1,20)
    return dano

def dano2():
    dano3=random.randint(1,20)
    return dano3


joao_cena = 100
joao_cenagolpes=0
mini_tison = 100
mini_tisongolpes=0

while joao_cena>0:
    while mini_tison>0:
        dano1=dano()
        dano3=dano2()
        joao_cena = joao_cena - dano1
        mini_tisongolpes+=1
        if joao_cena>0:
            print('\033[31mMini tison\033[m deu {} ao \033[34mjoão cena\033[m,\n \033[34mjoao cena\033[m está com {} vida'.format(dano1,joao_cena))
            time.sleep(2)
        else:
            print('Jeremias decreta que \033[31mMini tison\033[m Ganhou!!\n Com {} golpes'.format(mini_tisongolpes))
            sys.exit()
        mini_tison = mini_tison - dano3
        joao_cenagolpes+=1
        if mini_tison>0:
            print('\033[34mJoão Cena\033[m deu {} ao \033[31mmini tison\033[m,\n \033[31mmini tison\033[m estã com {} vida'.format(dano3,mini_tison))
            time.sleep(2)
        else:
            print('\033[32mJeremias\033[m decreta que \033[34mJoão Cena\033[m Ganhou\n Com {} golpes!!'.format(joao_cenagolpes))
            sys.exit()
