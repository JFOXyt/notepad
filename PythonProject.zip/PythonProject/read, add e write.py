with open('video.txt','w') as file1:
    file1.write('Bom dia')

with open('video.txt','a') as file1:
    novas_linhas = ['\n Linha 2','\n Linha 3']

    file1.writelines(novas_linhas)

with open('video.txt','r') as file1:
    conteudo = file1.read()
    print(conteudo)

    linha1 = file1.readline()
    print(linha1)

    linha2 = file1.readline()
    print(linha2)

    linhas = file1.readlines()
    for linha in linhas:
        print(linha)

