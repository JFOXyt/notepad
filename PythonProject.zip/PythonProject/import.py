import time

x=10

for i in range(11):
    print('\033[31m',x)
    x-=1
    time.sleep(1)