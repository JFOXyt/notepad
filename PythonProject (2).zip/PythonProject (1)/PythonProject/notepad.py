import time, os,glob
lisfilq=0
glub=glob.glob('*.txt')
sair=True
for file in glub:
        lisfilq+=1

while sair:

    noted=print('\033[32m[1]Ler\n\033[33m[2]Escrever\n\033[36m[3]Apagar\n\033[31m[4]Sair\n\033[34m[5]Novo Ficheiro\033[m\n\033[35m[6]Apagar ficheiro\033[m')
    note=int(input('Opção:'))
    if note==1:
        certo=True
        for i in range(lisfilq):
            print('\033[32m[{}]{}\033[m'.format(i+1,glub[i]))

        n=int(input('Opção:'))
        op=glub[n-1]
        note1=int(input('\033[33m[1]Ler tudo\n\033[34m[2]Ler linha\033[m'))
        with open(op,'r') as notes:
            if note1==1:
                notesp=notes.read()
                print(notesp)
            elif note1==2:
                notesp=notes.readlines()
                print('Qual linha queres ler')
                qnt=int(input('Escolha:'))
                if qnt - 1 < len(notesp):
                    print(notesp[qnt-1].strip())        

    elif note==2:
        for i in range(lisfilq):
            print('\033[33m[{}]{}\033[m'.format(i+1,glub[i]))
        n=int(input('Opção:'))
        op=glub[n-1]
        with open(op,'a')  as notes:
            tex=input('Texto:')
            notes.writelines(tex+"\n")
    elif note==3:
        for i in range(lisfilq):
            print('\033[33m[{}]{}\033[m'.format(i+1,glub[i]))
        n=int(input('Opção:'))
        op=glub[n-1]
        with open(op,'w') as notes:
            print('\033[31mApagado\033[m')
    elif note==4:
        print('A salvar ficheiros...')
        time.sleep(1)
        print('A fechar...')
        time.sleep(1)
        sair=False
    elif note==5:
        nom=input('\033[34mNome do ficheiro:\033[m')
        with open(nom+'.txt','w') as notes:
            print('\033[32mFicheiro criado\033[m')
            glub.append(nom+'.txt')
            lisfilq+=1
    elif note==6:
        for i in range(lisfilq):
            print('\033[33m[{}]{}\033[m'.format(i+1,glub[i]))
        n=int(input('Opção:'))
        op=glub[n-1]
        lisfilq-=1
        os.remove(op)
    