with open('write.txt','a') as file1:
    novas_linhas = ['\n Linha 2','\n Linha 3']

    file1.writelines(novas_linhas)