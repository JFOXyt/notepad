import tkinter as tk
from tkinter import messagebox

root=tk.Tk()
root.title('Jogo do Galo')

def clica_botao(index):
    global board, player_atual, buttons
    if board[index] == '':
        board[index] = player_atual
        buttons[index].config(text= player_atual)

        if verifica_vencedor():
            messagebox.showinfo('Game Over', f'Jogador {player_atual} Venceu')
            reset()
        elif '' not in board:
            messagebox.showinfo('Game Over', 'Empate!')
            reset()
        else:
            player_atual='O' if player_atual == 'X' else 'X'

def verifica_vencedor():
    combinacoes= [
        [0,1,2],[3,4,5],[6,7,8], #linha
        [0,3,6],[1,4,7],[2,5,8], #colunas
        [0,4,8],[2,4,6] #diagonais
    ]
    for comb in combinacoes:
        if board[comb[0]] == board[comb[1]] == board[comb[2]] != '':
            return True
    return False

def reset():
    global board, player_atual, buttons
    board = ['' for _ in range(9)]
    for button in buttons:
        button.config(text='')
    player_atual = 'X'

player_atual='X'
board=[''for _ in range(9)]
buttons=[]

for i in range(9):
    button=tk.Button(root,text='',width=5,height=2)
    button.grid(row=i//3, column=i%3)
    buttons.append(button)

root.mainloop()