import random,time

guito1=True
guito2=True

def cartaini():
    cartaini=random.randint(2,10)
    return cartaini

def cartaadd():
    cartaadd=random.randint(2,10)
    return cartaadd

def sm1():
    sm1=random.randint(1,5)
    return sm1
def sm2():
    sm2=random.randint(1,5)
    return sm2
def sm3():
    sm3=random.randint(1,5)
    return sm3

print('Bem vindo ao casino!!\nOs jogos são slot machine e BlackJack')
while guito1:
    guito=int(input('Quanto dinheiro queres apostar? (10,1000) '))
    if guito>=10 and guito<=1000:
        guito1=False
    else:
        print('Não podes apostar essa quantidade de dinheiro. ')

while guito2:
        sm11=sm1()
        sm22=sm2()
        sm33=sm3()
        cartaini1=cartaini()
        cartaadd1=cartaadd()
        cartabanca1=random.randint(1,21)
        print('Jogos:\n[1]Slot machine\n[2]BlackJack')
        jogo=int(input('Qual jogos queres jogar? '))
        if jogo==1:
            print('Slot machine:')
            time.sleep(1.5)
            print('Primeiro Valor: \033[32m{}\033[m'.format(sm11))
            time.sleep(1.5)
            print('Segundo Valor: \033[33m{}\033[m'.format(sm22))
            time.sleep(1.5)
            print('Terceiro Valor: \033[31m{}\033[m'.format(sm33))
            if sm11==sm22 and sm11==sm33 and sm33==sm22:
                guito*=100
                print('Ganhaste o JACKPOT\nTens agora {}'.format(guito))
            elif (sm11==sm22 and sm33!=sm11 and sm33!=sm22) or (sm11==sm33 and sm22!=sm11 and sm22!=sm33) or (sm22==sm33 and sm22!=sm11 and sm33!=sm11):
                guito*=5
                print('Ganhaste!\nTens agora {}'.format(guito))
            else:
                guito==0
                print('Perdeste!')
                break
        elif jogo==2:
                print('BlackJack:')
                print('A tua carta inicial é {}'.format(cartaini1))
                while cartaini1 < 21:
                        print(cartaini1)
                        print('Queres adicionar uma carta?\n[1]S\n[2]N')
                        op=int(input('Qual opção queres? '))
                        if op==1:
                            cartaini1+=cartaadd1
                            print('Tens agora {}'.format(cartaini1))
                        elif op==2:
                            print('Tens {}\nBanca:{}'.format(cartaini1,cartabanca1))
                            break
                        if cartabanca1<cartaini1:
                            print('Ganhaste\nTens agora {}'.format(guito*2))
                        elif cartabanca1==cartaini1:
                            print('Empataste')
                        else:
                            print('Perdeste')
                            break
                if cartaini1==21:
                    guito*=2
                    print('Ganaste!! \nTens agora {}'.format(guito))
                elif cartaini1>21:
                    guito==0
                    print('Perdeste')


print('Não podes jogar mais')