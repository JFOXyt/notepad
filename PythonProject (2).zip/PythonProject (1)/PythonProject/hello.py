import tkinter as tk

root=tk.Tk()
hello=0

def helo():
    global hello
    if hello==0:
        texthelo=tk.Label(root,text='Hello World')
        texthelo.pack()
        hello=1

root.geometry('500x350')

texto=tk.Label(root,text='Pressiona o botão')
butao=tk.Button(root,text='Botão',command=helo)

texto.pack()
butao.pack(pady=100)

root.mainloop()