with open('exemplo','w') as file1:
    file1.write('Hello World!\n')
    file1.write('JEREMIAS\n')
    file1.write('FÃ DO JEREMIAS\n')