with open('write.txt','r') as file1:
    conteudo = file1.read()
    print(conteudo)

    linha1 = file1.readline()
    print(linha1)

    linha2 = file1.readline()
    print(linha2)

    linhas = file1.readlines()
    for linha in linhas:
        print(linha)