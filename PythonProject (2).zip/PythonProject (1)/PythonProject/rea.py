with open('exemplo.txt','r') as file:
    content= file.readline()
    print(content)

    content1=file.readline()
    print(content1)

    content2=file.readline()
    print(content2)

    content3=file.readlines()
    for linha in content3:
        print(linha)